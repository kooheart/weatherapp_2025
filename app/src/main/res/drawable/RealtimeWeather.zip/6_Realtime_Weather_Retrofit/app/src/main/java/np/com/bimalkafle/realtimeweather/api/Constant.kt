package np.com.bimalkafle.realtimeweather.api

object Constant {

    val apiKey = "860d4463f26741f295373916250605"
}